// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract OffGridDAO {
    
    struct Proposal {
        uint256 id;
        string title;
        string description;
        string category;
        uint256 fundsRequested;
        uint256 votesYes;
        uint256 votesNo;
        bool active;
    }

    // Mapping of proposal ID to Proposal
    mapping(uint256 => Proposal) public proposals;
    
    // Track who voted on which proposal (proposalId => (voterAddress => true))
    mapping(uint256 => mapping(address => bool)) public hasVoted;

    // To iterate easily, we keep a counter of total proposals
    uint256 public proposalCount;

    // Events to let the backend know something happened instantly
    event ProposalCreated(uint256 indexed id, string title, uint256 fundsRequested);
    event VoteCast(address indexed voter, uint256 indexed proposalId, string vote, uint256 newYesCount, uint256 newNoCount);

    // Create a new proposal
    function createProposal(string memory _title, string memory _description, string memory _category, uint256 _fundsRequested) public {
        proposalCount++;
        proposals[proposalCount] = Proposal({
            id: proposalCount,
            title: _title,
            description: _description,
            category: _category,
            fundsRequested: _fundsRequested,
            votesYes: 0,
            votesNo: 0,
            active: true
        });
        
        emit ProposalCreated(proposalCount, _title, _fundsRequested);
    }

    // Cast a vote (true = Yes, false = No)
    function vote(uint256 _proposalId, bool _support) public {
        require(_proposalId > 0 && _proposalId <= proposalCount, "Proposal does not exist");
        require(proposals[_proposalId].active, "Proposal is no longer active");
        
        // For a hackathon demo, we comment this out so you can demo multiple taps with the same card!
        // require(!hasVoted[_proposalId][msg.sender], "You have already voted on this proposal");

        if (_support) {
            proposals[_proposalId].votesYes++;
        } else {
            proposals[_proposalId].votesNo++;
        }

        hasVoted[_proposalId][msg.sender] = true;

        string memory voteString = _support ? "yes" : "no";
        emit VoteCast(msg.sender, _proposalId, voteString, proposals[_proposalId].votesYes, proposals[_proposalId].votesNo);
    }

    // Helper to get all details of a proposal
    function getProposal(uint256 _proposalId) public view returns (Proposal memory) {
        return proposals[_proposalId];
    }
}
