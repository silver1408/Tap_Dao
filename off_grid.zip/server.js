const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { ethers } = require('ethers');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

// ─────────────────────────────────────────────
//  WEB3 BLOCKCHAIN SETUP (Hardhat localhost)
// ─────────────────────────────────────────────

const provider = new ethers.JsonRpcProvider("http://127.0.0.1:8545");

// Read ABI and deployed Address
const contractJSON = require('./artifacts/contracts/OffGridDAO.sol/OffGridDAO.json');
let contractAddress = "";
try {
    contractAddress = JSON.parse(fs.readFileSync('./address.json')).contractAddress;
} catch (e) {
    console.warn("⚠️ Warning: address.json not found. Run deployment script first.");
}

// We instantiate a read-only contract first. We will attach signers to it later.
let daoContract;
if (contractAddress) {
    daoContract = new ethers.Contract(contractAddress, contractJSON.abi, provider);
}

// Transaction Feed history cache
const transactionFeed = [];

// ─────────────────────────────────────────────
//  VOTER REGISTRY (Mapped to Hardhat Private Keys)
// ─────────────────────────────────────────────
// Hardhat provides 20 deterministic testing accounts. 
// We are mapping the first 3 to our specific physical NFC cards.
const voters = {
    'Metro_Card_001': {
        name: 'Grandma Patel',
        avatar: '👵',
        privateKey: '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80',
        ward: 'Sector 7, Green Park Colony',
    },
    'Metro_Card_002': {
        name: 'Uncle Sharma',
        avatar: '👴',
        privateKey: '0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d',
        ward: 'Sector 12, Riverside',
    },
    'Metro_Card_003': {
        name: 'Auntie Mehra',
        avatar: '👩',
        privateKey: '0x5de4111afa1a4b94908f83103eb1f1706367c2e68ca870fc3fb9a804cdab365a',
        ward: 'Sector 3, Market Road',
    },
};

function getVoter(cardId) {
    if (voters[cardId]) {
        // Compute public wallet address from private key instantly
        const wallet = new ethers.Wallet(voters[cardId].privateKey);
        return { cardId, ...voters[cardId], wallet: wallet.address };
    }
    // Fallback account 4 for unknown cards
    const fallbackWallet = new ethers.Wallet('0x7c852118294e51e653712a81e05800f419141751be58f605c371e15141b007a6');
    return {
        cardId,
        name: 'Community Member',
        avatar: '🧑',
        privateKey: fallbackWallet.privateKey,
        wallet: fallbackWallet.address,
        ward: 'Local Resident',
    };
}

let currentVoter = null;

// ─────────────────────────────────────────────
//  API ROUTES
// ─────────────────────────────────────────────

// Get all proposals from the SMART CONTRACT!
app.get('/proposals', async (req, res) => {
    if (!daoContract) return res.status(500).json({ error: 'Contract not deployed' });
    try {
        const count = await daoContract.proposalCount();
        const proposalsData = [];
        
        for (let i = 1; i <= Number(count); i++) {
            const p = await daoContract.getProposal(i);
            proposalsData.push({
                id: Number(p.id),
                title: p.title,
                description: p.description,
                category: p.category,
                fundsRequested: Number(p.fundsRequested),
                votesYes: Number(p.votesYes),
                votesNo: Number(p.votesNo),
                status: p.active ? 'active' : 'inactive'
            });
        }
        res.json(proposalsData);
    } catch (e) {
        console.error("Error reading blockchain:", e);
        res.status(500).json({ error: 'Failed to read blockchain state' });
    }
});


// NFC Scan → Identify Voter
app.get('/scan', (req, res) => {
    const cardId = req.query.cardId || 'Unknown_Card';
    console.log(`\n📡 NFC SCAN DETECTED: ${cardId}`);

    const voter = getVoter(cardId);
    currentVoter = voter;

    // We simulate the identity verify block logic locally still (could be put on chain as well)
    const txEntry = {
        id: transactionFeed.length + 1,
        type: 'IDENTITY_VERIFY',
        hash: '0x' + require('crypto').createHash('md5').update('identity' + Date.now()).digest('hex').slice(0,40),
        timestamp: new Date().toISOString()
    };
    transactionFeed.push(txEntry);

    // Broadcast to dashboard
    io.emit('card-scanned', {
        voter: { name: voter.name, avatar: voter.avatar, wallet: voter.wallet, ward: voter.ward, cardId: voter.cardId },
        transaction: txEntry,
    });

    res.json({ success: true, voter: voter.name });
});

// Cast a real Blockchain Vote
app.post('/vote', async (req, res) => {
    const { cardId, proposalId, vote } = req.body;

    if (!cardId || !proposalId || !vote) {
        return res.status(400).json({ error: 'Missing logic' });
    }

    const voter = getVoter(cardId);
    
    // Connect to blockchain securely via voter's private key
    const signer = new ethers.Wallet(voter.privateKey, provider);
    const connectedContract = daoContract.connect(signer);
    
    try {
        console.log(`⏳ Signing and sending TX to Blockchain for ${voter.name}...`);
        
        // Execute Smart Contract function
        const tx = await connectedContract.vote(proposalId, vote === 'yes');
        console.log(`⛓️  TX Sent! Hash: ${tx.hash}`);
        
        // Wait for it to be mined onto the local blockchain
        const receipt = await tx.wait();
        console.log(`⛏️  TX Mined! BlockNumber: ${receipt.blockNumber}, Gas Used: ${receipt.gasUsed.toString()}`);

        // We do NOT emit socket here immediately. 
        // We let the Event Listener catch it globally below safely!
        
        res.json({ success: true, transactionHash: tx.hash });
    } catch (e) {
        console.error("❌ Blockchain error:", e.reason || e.message);
        res.status(500).json({ error: e.reason || 'Blockchain execution failed' });
    }
});


// ─────────────────────────────────────────────
//  BLOCKCHAIN EVENT LISTENERS
// ─────────────────────────────────────────────
if (daoContract) {
    daoContract.on("VoteCast", async (voterAddr, proposalId, voteStr, yesVotes, noVotes, eventPayload) => {
        
        console.log(`\n🎉 EVENT RECEIVED: Real Vote Cast on Blockchain by ${voterAddr} for proposal ${proposalId}`);
        
        // Re-read proposal from chain to push to frontend
        const p = await daoContract.getProposal(proposalId);
        const proposalObj = {
            id: Number(p.id),
            title: p.title,
            description: p.description,
            category: p.category,
            fundsRequested: Number(p.fundsRequested),
            votesYes: Number(p.votesYes),
            votesNo: Number(p.votesNo),
            status: p.active ? 'active' : 'inactive'
        };

        const txHash = eventPayload.log.transactionHash;
        
        const txEntry = {
            id: transactionFeed.length + 1,
            type: 'VOTE_CAST',
            hash: txHash,
            timestamp: new Date().toISOString()
        };
        transactionFeed.push(txEntry);

        // Notify UI to flash Green Checkmark!
        io.emit('vote-recorded', {
            voter: currentVoter || { name: 'Voter', wallet: voterAddr },
            proposal: proposalObj,
            vote: voteStr,
            transaction: txEntry,
        });
    });
}


// ─────────────────────────────────────────────
//  SOCKET.IO
// ─────────────────────────────────────────────
io.on('connection', async (socket) => {
    console.log('🔌 Dashboard connected:', socket.id);

    // Bootstrap data dynamically from Blockchain
    let proposalsData = [];
    if (daoContract) {
        try {
            const count = await daoContract.proposalCount();
            for (let i = 1; i <= Number(count); i++) {
                const p = await daoContract.getProposal(i);
                proposalsData.push({
                    id: Number(p.id),
                    title: p.title,
                    description: p.description,
                    category: p.category,
                    fundsRequested: Number(p.fundsRequested),
                    votesYes: Number(p.votesYes),
                    votesNo: Number(p.votesNo),
                    status: p.active ? 'active' : 'inactive'
                });
            }
        } catch (e) {
            console.log("No deployed contract yet.");
        }
    }

    socket.emit('init', {
        proposals: proposalsData,
        transactions: transactionFeed.slice(-20),
        treasury: { totalFunds: 500000, allocated: 0, currency: 'DAO Tokens' },
        currentVoter,
    });
});

// ─────────────────────────────────────────────
//  START SERVER
// ─────────────────────────────────────────────
const PORT = 3001;
server.listen(PORT, '0.0.0.0', () => {
    console.log('');
    console.log('═══════════════════════════════════════════════');
    console.log('   🏛️  OFF-GRID DAO — ACTUAL WEB3 INSTANCE');
    console.log('═══════════════════════════════════════════════');
    console.log(`   Dashboard:  http://localhost:${PORT}`);
    console.log('═══════════════════════════════════════════════');
});
