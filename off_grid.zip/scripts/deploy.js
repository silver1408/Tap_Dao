const hre = require("hardhat");

async function main() {
    console.log("Deploying OffGridDAO...");

    // Get the ContractFactory and Signers here.
    const DAO = await hre.ethers.getContractFactory("OffGridDAO");
    const dao = await DAO.deploy();

    await dao.waitForDeployment();
    
    // Log the deployed address
    const contractAddress = await dao.getAddress();
    console.log(`\n🎉 OffGridDAO deployed to: ${contractAddress}\n`);
    
    // Save it for the server
    const fs = require('fs');
    fs.writeFileSync('address.json', JSON.stringify({ contractAddress }));

    console.log("Seeding initial proposals...");

    // Seed the identical proposals from the Node.js simulation
    const tx1 = await dao.createProposal(
        "Park Bench Renovation",
        "Install 12 new solar-powered benches in Green Park with USB charging stations for residents.",
        "Infrastructure",
        45000
    );
    await tx1.wait();

    const tx2 = await dao.createProposal(
        "Community Solar Panels",
        "Install rooftop solar panels on the community hall to reduce electricity bills by 60%.",
        "Energy",
        120000
    );
    await tx2.wait();

    const tx3 = await dao.createProposal(
        "Free Wi-Fi Zones",
        "Set up 5 free Wi-Fi hotspots in public areas — park, market, bus stop, library, and temple.",
        "Digital",
        30000
    );
    await tx3.wait();

    console.log("✅ Seeded 3 proposals!");
    console.log("Deployment fully complete. You can now start the server.\n");
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
